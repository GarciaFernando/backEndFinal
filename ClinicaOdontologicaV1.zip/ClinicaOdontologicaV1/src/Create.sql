CREATE TABLE IF NOT EXISTS odontologos(id INTEGER auto_increment primary key NOT NULL, nombre VARCHAR(255), apellido VARCHAR(255), matricula VARCHAR(255));

CREATE TABLE IF NOT EXISTS pacientes(id INTEGER auto_increment primary key NOT NULL, nombre VARCHAR(255), apellido VARCHAR(255), domicilio VARCHAR(255), dni VARCHAR(255), fechaAlta DATE);