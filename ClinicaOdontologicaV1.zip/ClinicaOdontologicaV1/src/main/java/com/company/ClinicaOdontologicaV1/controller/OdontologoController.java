package com.company.ClinicaOdontologicaV1.controller;

import com.company.ClinicaOdontologicaV1.entity.Odontologo;
import com.company.ClinicaOdontologicaV1.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OdontologoController {

    @Autowired
    OdontologoService odontologoService;

    @PostMapping("/agregarodontologo")
    public Odontologo agregarOdontologo(@RequestBody Odontologo odontologo){
        return odontologoService.agregar(odontologo);

    }

    @GetMapping("/odontologo")
    public List<Odontologo> obtenerOdontologos(){
        List<Odontologo> listaOdontologos= odontologoService.listarTodos();
        return listaOdontologos;
    }
    @GetMapping("/odontologo/{id}")
    public Odontologo buscarOdontologoPorId(@PathVariable Long id){
        return odontologoService.buscarPorId(id);
    }
}
