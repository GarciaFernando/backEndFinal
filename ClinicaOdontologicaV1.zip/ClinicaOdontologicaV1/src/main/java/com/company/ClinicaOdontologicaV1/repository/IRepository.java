package com.company.ClinicaOdontologicaV1.repository;

import java.util.List;

public interface IRepository<T>{
    T agregar(T t);
    T modificar(T t);
    void eliminar(Long t);
    T buscarPorId(Long t);
    List<T> listarTodos();

}
