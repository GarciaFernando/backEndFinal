package com.company.ClinicaOdontologicaV1;

import com.company.ClinicaOdontologicaV1.entity.Odontologo;
import com.company.ClinicaOdontologicaV1.service.OdontologoService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class ClinicaOdontologicaV1Application {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaOdontologicaV1Application.class, args);
		Odontologo odontologo1 = new Odontologo(1L,"Garcia","Fernando","123");
		Odontologo odontologo2 = new Odontologo(2L,"Gar","Fer","456");
		Odontologo odontologo3 = new Odontologo(3L,"Asd","Qwe","789");

		ConfiguracionJDBC configuracionJDBC= new ConfiguracionJDBC();
		OdontologoService odontologoService = new OdontologoService();
		odontologoService.setOdontologoIDao(new OdontologoDaoH2(configuracionJDBC));

		odontologoService.agregar(odontologo1);
		odontologoService.agregar(odontologo2);
		odontologoService.agregar(odontologo3);

		List<Odontologo> lista = odontologoService.listarTodos();
		for(Odontologo o : lista){
			System.out.println(o.toString());
		}
	}

}
