package com.company.ClinicaOdontologicaV1.service;
import com.company.ClinicaOdontologicaV1.dto.OdontologoDTO;
import com.company.ClinicaOdontologicaV1.entity.Odontologo;
import com.company.ClinicaOdontologicaV1.repository.IOdontologoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class OdontologoService {

    private final IOdontologoRepository odontologoRepository;

    @Autowired
    public OdontologoService(IOdontologoRepository odontologoRepository) {
        this.odontologoRepository = odontologoRepository;
    }
    public List<OdontologoDTO> obtenerOdontologo(){
        ObjectMapper mapper = new ObjectMapper();
        List<OdontologoDTO> listaDTO=null;
        for(Odontologo o : odontologoRepository.findAll()){
            listaDTO.add(mapper.convertValue(o,OdontologoDTO.class));
        }
        return listaDTO;
    }
    public List<OdontologoDTO> obtenerOdontologoPorNombre(String nombre){
        List<Odontologo> listaOdontologos = odontologoRepository.buscarOdontologosPorNombre(nombre);
        List<OdontologoDTO> listaDTO = null;
        ObjectMapper mapper = new ObjectMapper();
        for(Odontologo o : listaOdontologos){
            listaDTO.add(mapper.convertValue(o,OdontologoDTO.class));
        }
        return listaDTO;
    }


}