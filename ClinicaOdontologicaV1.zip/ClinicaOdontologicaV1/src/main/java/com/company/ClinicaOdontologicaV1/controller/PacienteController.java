package com.company.ClinicaOdontologicaV1.controller;

import com.company.ClinicaOdontologicaV1.entity.Paciente;
import com.company.ClinicaOdontologicaV1.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PacienteController {

    @Autowired
    PacienteService pacienteService;


    @GetMapping("/email")
    public String getPacienteByEmail(@RequestParam(name="name",required = false,defaultValue = "example@gmail.com")String email, Model model){
        Paciente paciente = pacienteService.buscarPacientePorEmail(email);
        if(paciente==null) return "No se encontro paciente";
        model.addAttribute("nombre",paciente.getNombre());
        model.addAttribute("apellido",paciente.getApellido());

        return "index";
    }
}
