package com.company.ClinicaOdontologicaV1.controller;


import com.company.ClinicaOdontologicaV1.dto.TurnoDTO;
import com.company.ClinicaOdontologicaV1.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/turnos")
public class TurnoController {

    @Autowired
    TurnoService turnoService;

    @GetMapping("{id}")
    public ResponseEntity<TurnoDTO> obtenerTurno(@PathVariable Long id){
        return ResponseEntity.ok(turnoService.buscarPorId(id));
    }
    @PutMapping("/")
    public ResponseEntity<TurnoDTO> actualizarTurno(@ResponseBody Turno turno){

    }
}
