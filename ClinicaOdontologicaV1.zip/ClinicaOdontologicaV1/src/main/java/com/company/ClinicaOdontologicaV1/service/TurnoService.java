package com.company.ClinicaOdontologicaV1.service;

import com.company.ClinicaOdontologicaV1.dto.TurnoDTO;
import com.company.ClinicaOdontologicaV1.entity.Turno;
import com.company.ClinicaOdontologicaV1.repository.IRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TurnoService {

    private IRepository<Turno> turnoIRepository;
    public TurnoService(){}

    public TurnoService(IRepository<Turno> turnoIRepository) {
        this.turnoIRepository = turnoIRepository;
    }

    public Turno agregar(Turno t){
        return turnoIRepository.agregar(t);
    }
    public TurnoDTO buscarPorId(Long id){
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(turnoIRepository.buscarPorId(id),TurnoDTO.class);
    }
    public Turno modificar(Turno t){
        return turnoIRepository.modificar(t);
    }
    public void eliminar(Long t){
        turnoIRepository.eliminar(t);
    }
    public List<TurnoDTO> listarTodos(){
        ObjectMapper mapper = new ObjectMapper();
        List<TurnoDTO> listaDTO = new ArrayList<>();
        for(Turno turno : turnoIRepository.listarTodos()){
            listaDTO.add(mapper.convertValue(turno,TurnoDTO.class));
        }
        return listaDTO;

    }
}
