package com.company.ClinicaOdontologicaV1.service;

import com.company.ClinicaOdontologicaV1.entity.Domicilio;
import com.company.ClinicaOdontologicaV1.entity.Odontologo;
import com.company.ClinicaOdontologicaV1.entity.Paciente;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class PacienteService {
    private List<Paciente> pacientes = new ArrayList<>();

    public PacienteService(){
        pacientes.add(new Paciente(1L,"Perez","Facundo","12345678","asd@gmail.com",new Domicilio(), LocalDate.now()));
    }

    public List<Paciente> listarPacientes(){
        return pacientes;
    }

    public Paciente buscarPacientePorEmail(String email){
        return pacientes.stream().filter(x-> x.getEmail().equals(email)).findFirst().orElse(null);
    }

}