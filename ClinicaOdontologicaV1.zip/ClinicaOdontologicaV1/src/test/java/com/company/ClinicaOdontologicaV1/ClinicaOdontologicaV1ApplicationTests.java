package com.company.ClinicaOdontologicaV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontologicaV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
